/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reto5p41;

import Vista.VistaRequerimientos;
import Vista.Consultas;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eescobarm
 */
public class Reto5P41 {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        /* System.out.println("Requerimiento 1");
        VistaRequerimientos.requerimiento1();
        System.out.println("");
        System.out.println("Requerimiento 2");
        VistaRequerimientos.requerimiento2();
        System.out.println("");
        System.out.println("Requerimiento 3");
        VistaRequerimientos.requerimiento3(); */
        
    }
    
}
